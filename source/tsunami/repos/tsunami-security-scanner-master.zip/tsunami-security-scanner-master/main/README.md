# Tsunami Main

## Overview

This module provides the entry point for starting up Tsunami Security Scanner.
